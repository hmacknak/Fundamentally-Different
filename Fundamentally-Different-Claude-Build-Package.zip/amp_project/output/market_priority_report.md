# Market Priority Report

As of rebalance date: **2025-09-30**
Universe: 60 tickers | Rebalance: Q | Holding: 3m | Rolling window: 8 periods | Fundamental reporting lag enforced: 60 days

Returns are benchmark-relative (excess) throughout.

## What the market appears to be prioritizing

| Priority | Score (mean rolling IC) | Q-spread | Trend | Evidence base |
|---|---|---|---|---|
| Inflation protection | 0.079 | 0.0275 | strengthening | 4/4 factors |
| Valuation discipline | 0.046 | 0.0137 | strengthening | 3/3 factors |
| Growth scarcity | 0.043 | 0.0122 | strengthening | 4/4 factors |
| Cash generation | 0.042 | 0.0184 | strengthening | 3/3 factors |
| Balance sheet strength | 0.034 | 0.0118 | strengthening | 3/3 factors |
| Capital discipline | 0.017 | 0.0009 | strengthening | 3/3 factors |
| Risk avoidance | 0.001 | 0.0006 | strengthening | 4/4 factors |

The strongest current evidence points to **Inflation protection** (score 0.079, strengthening), followed by **Valuation discipline** (0.046).

Scores are rolling averages over a small number of quarterly observations; treat rankings between closely scored priorities as indistinguishable.

## Factor evidence behind the diagnosis

| Factor | Rolling IC | ±SE | t | Hit rate | Trend (4-period) |
|---|---|---|---|---|---|
| revenue_growth | 0.161 | 0.063 | 2.57 | 0.62 | strengthening |
| interest_coverage | 0.136 | 0.040 | 3.41 | 1.00 | strengthening |
| commodity_sensitivity | 0.105 | 0.058 | 1.80 | 0.62 | strengthening |
| low_beta | 0.094 | 0.045 | 2.08 | 0.75 | strengthening |
| fcf_yield | 0.087 | 0.073 | 1.18 | 0.62 | strengthening |
| low_volatility | 0.048 | 0.089 | 0.55 | 0.38 | strengthening |
| operating_margin | 0.036 | 0.044 | 0.82 | 0.50 | weakening |
| earnings_yield | 0.028 | 0.047 | 0.60 | 0.50 | weakening |
| roe | 0.022 | 0.032 | 0.69 | 0.62 | strengthening |
| momentum_6m | 0.022 | 0.038 | 0.57 | 0.50 | strengthening |
| ev_ebitda_inv | 0.022 | 0.027 | 0.79 | 0.62 | stable |
| gross_margin | 0.013 | 0.045 | 0.28 | 0.38 | stable |
| free_cash_flow_margin | 0.004 | 0.045 | 0.08 | 0.50 | strengthening |
| dividend_yield | -0.021 | 0.046 | -0.46 | 0.62 | strengthening |
| eps_revision | -0.034 | 0.043 | -0.78 | 0.50 | weakening |
| shares_dilution_inv | -0.058 | 0.059 | -0.98 | 0.38 | weakening |
| debt_to_equity_inv | -0.119 | 0.059 | -2.02 | 0.38 | strengthening |

## Why these criteria may matter now (interaction evidence)

136 factor x macro pairs tested jointly; Benjamini-Hochberg FDR at q<=0.10 controls false discoveries. **2 relationship(s) survive.** Non-survivors are not narrated.

| Factor | Macro state | b | t | q | n | Reading |
|---|---|---|---|---|---|---|
| fcf_yield | credit_spread_z | 0.0156 | 7.22 | 0.000 | 32 | payoff tends higher when this state is elevated — consistent with the market rewarding internally funded businesses when external capital is expensive |
| free_cash_flow_margin | credit_spread_z | 0.0093 | 4.32 | 0.011 | 32 | payoff tends higher when this state is elevated — mechanism not pre-mapped — interpret with care |

These are conditional associations, not causal proof.

## Shared evidence between priorities (read before comparing them)

Priorities share member factors by design, so their scores are correlated. Jaccard overlap of evidence sets:

| | Cash generation | Balance sheet strength | Growth scarcity | Valuation discipline | Risk avoidance | Inflation protection | Capital discipline |
|---|---|---|---|---|---|---|---|
| **Cash generation** | 1.00 | 0.20 | 0.00 | 0.20 | 0.00 | 0.17 | 0.20 |
| **Balance sheet strength** | 0.20 | 1.00 | 0.00 | 0.20 | 0.17 | 0.00 | 0.20 |
| **Growth scarcity** | 0.00 | 0.00 | 1.00 | 0.00 | 0.00 | 0.14 | 0.17 |
| **Valuation discipline** | 0.20 | 0.20 | 0.00 | 1.00 | 0.00 | 0.00 | 0.20 |
| **Risk avoidance** | 0.00 | 0.17 | 0.00 | 0.00 | 1.00 | 0.00 | 0.00 |
| **Inflation protection** | 0.17 | 0.00 | 0.14 | 0.00 | 0.00 | 1.00 | 0.00 |
| **Capital discipline** | 0.20 | 0.20 | 0.17 | 0.20 | 0.00 | 0.00 | 1.00 |

## Top-ranked candidates under the current priority weights

Ranking is downstream of the diagnosis. Weights (positive-score normalized): Inflation protection 30%, Valuation discipline 17%, Growth scarcity 16%, Cash generation 16%, Balance sheet strength 13%, Capital discipline 6%, Risk avoidance 0%

| # | Ticker | Composite |
|---|---|---|
| 1 | SYN019 | 0.723 |
| 2 | SYN004 | 0.656 |
| 3 | SYN012 | 0.640 |
| 4 | SYN043 | 0.635 |
| 5 | SYN020 | 0.635 |
| 6 | SYN042 | 0.634 |
| 7 | SYN009 | 0.627 |
| 8 | SYN017 | 0.626 |
| 9 | SYN005 | 0.621 |
| 10 | SYN030 | 0.619 |
| 11 | SYN049 | 0.616 |
| 12 | SYN048 | 0.604 |
| 13 | SYN027 | 0.599 |
| 14 | SYN035 | 0.595 |
| 15 | SYN011 | 0.588 |
| 16 | SYN025 | 0.585 |
| 17 | SYN028 | 0.575 |
| 18 | SYN047 | 0.574 |
| 19 | SYN034 | 0.574 |
| 20 | SYN023 | 0.569 |

## Control test: planted-signal recovery (synthetic run)
- PLANTED conditional effect (fcf_yield x credit_spread_z): RECOVERED (b=0.0156, t=7.22, q=0.000)
- PLANTED unconditional effect (revenue_growth): RECOVERED (rolling IC=0.161, t=2.57)
- FDR survivors not planted — check correlation with planted factors before calling them false positives: ['free_cash_flow_margin x credit_spread_z (rank-corr with planted fcf_yield: +0.38)']

## Limitations (auto-included)
- Research tool, not investment advice. No trading, no performance guarantee.
- Quarterly rebalancing yields few observations; all statistics carry wide uncertainty.
- Correlation-based evidence throughout; interaction terms support, never prove, mechanisms.
- Real-world use requires point-in-time fundamentals, survivorship-free universe, transaction costs, and out-of-sample validation.
