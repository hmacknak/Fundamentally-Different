# Data Quality Report

- Prices: 141,000 rows, 60 tickers, 2017-01-02 to 2026-01-02
- Fundamentals: 2,160 rows, 60 tickers
- Macro: 108 rows, 2017-01-31 to 2025-12-31
- Usable universe (price+fundamental overlap): 60 tickers

No data quality issues detected.
